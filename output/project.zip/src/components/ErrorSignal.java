package components;

public class ErrorSignal { 
	public String error;
	public String origin;
	public ErrorSignal (String  error, String origin) { 
		this.error = error;
		this.origin = origin;
	}
}
package components;

public class ChaincodeTransitionsClass {
    

	interface TaskRunner { 
        Result run(Result res);
    }

	private chaincodeTaskClass ChaincodeRunner = new chaincodeTaskClass();

	private Result tasksRunner (TaskRunner[] tasks, String relation,  String parentRelation,Result result){ 
        Result lastRes = result;
        for (TaskRunner run : tasks) { 
            Result res = run.run(lastRes);
            
            res = verifyContinuation(res, relation, parentRelation == "and");
            
            lastRes.update(res);
            if (res.locked()) { 
                break;
            }
            
        }
        return lastRes;
    }
	private Result verifyContinuation(Result result, String relation, boolean canLock) { 
    if (((result.getError() == null && result.isSuccess())&& relation == "or") || ((result.getError() != null && !result.isSuccess())&& relation == "and")) { 
        if (canLock) { 
            result.lock();
        }
    }
    // before continuing to next functions  
    if (!result.locked()) { 
        result.resetError();
    }
    return result;
}

	public Result execute_bussiness_logic_runner(Result result) {

       
        if (result.locked()) { 
            return result;
        }
        
        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return ChaincodeRunner.Execute_requested_contract_function_task(res);}}
        };
        return tasksRunner(runners, "and", "and", result);

       
        //Goes to state: output_state
    }


}
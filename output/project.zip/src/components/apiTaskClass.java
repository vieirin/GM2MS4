package components;

public class apiTaskClass {
    

	public Result Validar_entrada_task (Result result) { 

            return result;
        }
	public Result Outra_task_task (Result result) { 

            return result;
        }
	public Result Montar_proposta_de_transacao_task (Result result) { 

            return result;
        }
	public Result Calcular_peers_alvo_task (Result result) { 

            return result;
        }
	public Result Enviar_proposta_para_os_peers_alvo_task (Result result) { 

            return result;
        }
	public Result Enviar_erro_task (Result result) { 

            return result;
        }
}
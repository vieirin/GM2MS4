package components;

public class peerTaskClass {
    

	public Result Broadcast_transaction_result_pool_to_channel_task (Result result) { 

            return result;
        }
	public Result Unicast_transaction_result_through_grpc_task (Result result) { 

            return result;
        }
}
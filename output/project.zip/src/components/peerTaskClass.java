package components;

public class peerTaskClass {
    

	public Result Enviar_resultado_para_api_task (Result result) { 

            return result;
        }
}
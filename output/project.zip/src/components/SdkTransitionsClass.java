package components;

public class SdkTransitionsClass {
    

	interface TaskRunner { 
        Result run(Result res);
    }

	private sdkTaskClass SdkRunner = new sdkTaskClass();

	private Result tasksRunner (TaskRunner[] tasks, String relation,  String parentRelation,Result result){ 
        Result lastRes = result;
        for (TaskRunner run : tasks) { 
            Result res = run.run(lastRes);
            
            res = verifyContinuation(res, relation, parentRelation == "and");
            
            lastRes.update(res);
            if (res.locked()) { 
                break;
            }
            
        }
        return lastRes;
    }
	private Result verifyContinuation(Result result, String relation, boolean canLock) { 
    if (((result.getError() == null && result.isSuccess())&& relation == "or") || ((result.getError() != null && !result.isSuccess())&& relation == "and")) { 
        if (canLock) { 
            result.lock();
        }
    }
    
    return result;
}

	public Result find_the_target_peers_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return SdkRunner.Search_for_peers_on_discovery_channel_task(res);}},
		   new TaskRunner() {public Result run(Result res) {return broadcast_search_message_runner(res);}},
		   new TaskRunner() {public Result run(Result res) {return SdkRunner.Extract_from_local_config_file_task(res);}}
        };
        return tasksRunner(runners, "or", "and", result);

       
        //Goes to state: Broadcast_search_message
    }

public Result broadcast_search_message_runner(Result result) {

        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return SdkRunner.Broadcast_through_TCP_task(res);}},
		   new TaskRunner() {public Result run(Result res) {return SdkRunner.Broadcast_through_UDP_task(res);}}
        };
        return tasksRunner(runners, "or", "or", result);

    }
	public Result send_trasaction_request_to_peers_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return send_request_through_tcp_runner(res);}}
        };
        return tasksRunner(runners, "and", "and", result);

       
        //Goes to state: Send_request_through_TCP
    }

public Result send_request_through_tcp_runner(Result result) {

        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return SdkRunner.Send_request_through_gRPC_task(res);}},
		   new TaskRunner() {public Result run(Result res) {return SdkRunner.Send_request_through_REST_task(res);}}
        };
        return tasksRunner(runners, "or", "and", result);

    }
	public Result receive_result_pool_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: Verify_result_pool
    }

	public Result verify_result_pool_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return SdkRunner.Verify_peer_response_task(res);}}
        };
        return tasksRunner(runners, "and", "and", result);

       
        //Goes to state: Send_signed_transaction_to_Orderer
    }

	public Result send_signed_transaction_to_orderer_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: Validate_block_signatures
    }

	public Result validate_block_signatures_continue_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: output_state
    }


}
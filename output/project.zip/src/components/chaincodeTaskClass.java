package components;

public class chaincodeTaskClass {
    

	public Result Execute_requested_contract_function_task (Result result) { 

            return result;
        }
}
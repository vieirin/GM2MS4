package components;

public class chaincodeTaskClass {
    

	public Result Executar_funcao_solicitada_task (Result result) { 

            return result;
        }
}
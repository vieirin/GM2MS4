package components;

public class ordererTaskClass {
    

	public Result Check_signatures_task (Result result) { 

            return result;
        }
	public Result Add_block_to_chain_task (Result result) { 

            return result;
        }
	public Result Notify_the_network_task (Result result) { 

            return result;
        }
}
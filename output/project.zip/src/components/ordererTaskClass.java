package components;

public class ordererTaskClass {
    

	public Result Task_task (Result result) { 

            return result;
        }
	public Result Adicionar_bloco_a_cadeia_task (Result result) { 

            return result;
        }
	public Result Notificar_a_rede_task (Result result) { 

            return result;
        }
}
package components;

public class PeerTransitionsClass {
    

	interface TaskRunner { 
        Result run(Result res);
    }

	private peerTaskClass PeerRunner = new peerTaskClass();

	private Result tasksRunner (TaskRunner[] tasks, String relation,  String parentRelation,Result result){ 
        Result lastRes = result;
        for (TaskRunner run : tasks) { 
            Result res = run.run(lastRes);
            
            res = verifyContinuation(res, relation, parentRelation == "and");
            
            lastRes.update(res);
            if (res.locked()) { 
                break;
            }
            
        }
        return lastRes;
    }
	private Result verifyContinuation(Result result, String relation, boolean canLock) { 
    if (((result.getError() == null && result.isSuccess())&& relation == "or") || ((result.getError() != null && !result.isSuccess())&& relation == "and")) { 
        if (canLock) { 
            result.lock();
        }
    }
    
    return result;
}

	public Result calculate_transaction_result_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: Invoke_chaincode
    }

	public Result invoke_chaincode_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: Execute_bussiness_logic
    }

	public Result execute_bussiness_logic_continue_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        return result;
       
        //Goes to state: output_state
    }


	public Result return_contract_execution_result_runner(Result result) {

       result = verifyContinuation(result, "and" , true);
        if (result.locked()) { 
            return result;
        }
        
        TaskRunner[] runners = new TaskRunner[] { 
           new TaskRunner() {public Result run(Result res) {return PeerRunner.Broadcast_transaction_result_pool_to_channel_task(res);}},
		   new TaskRunner() {public Result run(Result res) {return PeerRunner.Unicast_transaction_result_through_grpc_task(res);}}
        };
        return tasksRunner(runners, "or", "and", result);

       
        //Goes to state: output_state
    }


}